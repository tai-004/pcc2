from django.contrib import admin
from .models import Tabela
# Register your models here.

admin.site.register(Tabela)
