from django.contrib import admin
from noti.models import Notificacao, Tabela_notis

admin.site.register(Notificacao)
admin.site.register(Tabela_notis)
