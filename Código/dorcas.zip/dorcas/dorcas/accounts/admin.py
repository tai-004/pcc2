from django.contrib import admin
from accounts.models import Profile, Instituicao
# Register your models here.

admin.site.register(Profile)

admin.site.register(Instituicao)

